import "./App.css";
import DiaryEditor from "./DiaryEditor";

function App() {
  return (
    <div className="App">
      <DiaryEditor />
    </div>
  );
}

export default App;
