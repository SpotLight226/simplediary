import { useRef, useState } from "react";

const DiaryEditor = () => {
  const authorInput = useRef();
  const contentInput = useRef();

  // 2. 하나의 state 로 묶기 !!
  const [state, setState] = useState({
    author: "",
    content: "",
    emotion: 1,
  });

  // event 함수 통합
  const handleChangeState = (event) => {
    console.log(event.target.name);
    console.log(event.target.value);

    setState({
      ...state,
      // state의 파라미터 명 == event.target.name
      [event.target.name]: event.target.value,
    });
  };

  const handleSubmit = () => {
    // 입력값 핸들링
    if (state.author.length < 1) {
      alert("작성자는 최소 1글자 이상 입력해주세요");
      // 현재 가르키는 값을 current 로 사용 가능
      // focus
      authorInput.current.focus();
      //focusㅁㅁㅁㅁㅁㅁㅁㅁㅁㅁㅁㅁㅁㅁㅁㅁㅁㅁㅁㅁㅁㅁㅁㅁㅁㅁㅁㅁㅁㅁㅁㅁㅁㅁㅁ                                                                                                                                                                                                                                                                    ㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹ
      return;
    }

    if (state.content.length < 5) {
      alert("일기의 본문은 최소 5글자 입력해주세요");
      // focus
      return;
    }
    alert("저장 성공");
  };

  // 1. input의 값을 핸들링할 수 있게 state 이용
  // const [author, setAuthor] = useState("");
  // const [content, setContent] = useState("");

  return (
    <div className="DiaryEditor">
      <h2>오늘의 일기</h2>
      <div>
        <input
          // input 태그의 name
          name="author"
          value={state.author}
          // 값이 바뀌었을 때 수행하는 이벤트
          // 각 해당하는 값이 변경될 때만 state 객체에서 해당하는 변수의 값이 변경
          // state 는 객체이므로, 객체로 전달한다 !!
          onChange={handleChangeState}
        />
      </div>
      <div>
        {/* 사용법은 input 태그와 동일  value에 state, set함수에 event.target의 value*/}
        <textarea
          name="content"
          value={state.content}
          onChange={handleChangeState}
        />
      </div>
      <div>
        {/* select 태그 다루기 */}
        <select
          name="emotion"
          value={state.emotion}
          onChange={handleChangeState}
        >
          <option value={1}>1</option>
          <option value={2}>2</option>
          <option value={3}>3</option>
          <option value={4}>4</option>
          <option value={5}>5</option>
        </select>
      </div>
      <div>
        <button onClick={handleSubmit}>일기 저장하기</button>
      </div>
    </div>
  );
};

export default DiaryEditor;
